<?php

/**
 * Teletext image viewer
 * 
 * @version $Id$
 * @copyright 2010 Rob O'Donnell. robert@irrelevant.com
 * 
*  Version 0.4 beta
* 
* This will be licenced under an open source licence as soon as I get around to
* * choosing one.
* 
 * This is a very simple renderer that **cannot cope with "dynamic" frames! **
 * 
 * 
 * Call with ttxview.php?page=65656a
 * where page = filename to load
 * width = width in columns
 * height = height in lines
 * format = 0 - auto, 1=mode7, 2=gnome, 3=raw
 * add 128 to enable black
  * add 64 to disable cache write
*   add 32 to disable cache read
 * 
 * 
 * First things first.  Image size.
 * 40 x 25 lines by default
 * font is 20 high x 12 wide
 */

include "GIFEncoder.class.php";

$error = "";
// image size in characters
$width = 40;
if (isset($_GET["width"])) {
    if (is_numeric($_GET["width"])) $width = $_GET["width"]; 
    // else $error = "Invalid width";
} 

$height = 25;
if (isset($_GET["height"])) {
    if (is_numeric($_GET["height"])) $height = $_GET["height"]; 
    // else $error = "Invalid height";
} 
// font sizes. must match that in font files
$fwidth = 12;
$fheight = 20; 
// border in pixels
$tborder = 5; // top & bottom
$lborder = 12; // left and right  
// pause time per frame for flashing
$flashdelay[0] = 100;
$flashdelay[1] = 33; 
// config stuff
$black = 0; // support black ink (not available on SAA5050...)
// what to display..
$donotcache = 0;
$alwaysrender=0;
$page = "";
if (isset($_GET["page"])) {
    if (preg_match('/^[a-zA-Z0-9_]{3,16}$/', $_GET['page'])) $page = $_GET["page"];
    else $error = "Invalid page number";
} 
// what format is it in?
$format = 0;
if (isset($_GET["format"])) {
    if (is_numeric($_GET["format"])) {
        $format = 0 + $_GET["format"];
        if ($format & 128) {
            $black = 1;
            $format -= 128;
        } 
        if ($format & 64) {
            $donotcache = 1;
            $format -= 64;
        } 
        if ($format & 32) {
            $alwaysrender = 1;
            $format -= 32;
        } 
    } else $error = "Invalid format";
} 
// first check to see if cached copy already exists
// gif image (for animations)
if ($alwaysrender != 1 && $page != "" && file_exists("./cache/" . $page . ".gif")) {
    // TODO observe dates, etc, to ensure is up to date)
    // can't use imagegif as this loses the animation!!
    $my_img = file_get_contents("./cache/" . $page . ".gif");
    header("Content-type: image/gif");
    echo $my_img;
} else if ($alwaysrender != 1 && $page != "" && file_exists("./cache/" . $page)) { // standard image
    // TODO observe dates, etc, to ensure is up to date)
    $my_img = imagecreatefrompng("./cache/" . $page);
    header("Content-type: image/png");
    imagepng($my_img);
    imagedestroy($my_img);
} else {
    // read fonts
    $fontnum = imageloadfont("./vvttxt.gdf");
    $fontnumtop = imageloadfont("./vvttxtop.gdf");
    $fontnumbot = imageloadfont("./vvttxbtm.gdf");

    if ($fontnum == 0 || $fontnumtop == 0 || $fontnumbot == 0) {
        $error = "cannot find font file";
    } else {
        // .. read file ..
        if ($page == "" || $error != "") {
            if ($error != "") {
                $text = chr(129) . chr(157) . chr(135) . $error . "  " . chr(156);
                $donotcache = 1;
            } else { // sample text
                $text = "The" . chr(129) . "quick" . chr(130) . "brown" . chr(131)
                 . "fox" . chr(132) . "jumped" . chr(133) . "over" . chr(134) . "the" .
                chr(135) . "lazy" . "dog" . chr(136) . "0123456789 ![]{}^#" . chr(141) . "Double" . chr(140) . "Height    " . "0123456789012345678901234567890123456789" . " Viewdata Viewer (C)2010 Rob O'Donnell  " .
                chr(147) . "ssss" . chr(154) . "ssss" . chr(153) . "ssss" ;
                $donotcache = 1;
            } 
        } else {
            $text = "";
            if (file_exists("./frames/" . $page))
                $text = file_get_contents("./frames/" . $page);
            else {
                $text = chr(129) . chr(157) . chr(135) . "File not found  " . chr(156);
                $donotcache = 1;
                $format = 1;
            } 
            if ($format == 0) {
                if (chr(127&ord(substr($text, 143, 1))) == "p" &&
                        is_numeric(chr(127&ord(substr($text, 142, 1))))) {
                    $format = 2;
                } 
            } 

            if ($format == 2) {
                $text = substr($text, 104, 920);
                $height = 24; // 23+1 blank. and it's too late..
            } 
        } 
    } 
    // image size in pixels
    $pwidth = $width * $fwidth + 2 * $lborder;
    $pheight = $height * $fheight + 2 * $tborder; 
    // create canvas
    $my_img = imagecreate($pwidth, $pheight); 
    // define the colours
    for ($i = 0; $i < 8; $i++) {
        $colour[$i] = imagecolorallocate($my_img, ($i &1)?255:0, ($i &2)?255:0, ($i &4)?255:0);
    } 
    // flasher flag
    $flasher = 0;
    $flashcycle = 0;
    do { // for each flashcycle
        if ($flasher > 0) $flashcycle++; 
        // starting character position
        $cx = 0;
        $cy = 0; 
        // starting forground and background colours
        $doublebottom = 0;
        $nextbottom = 0;
        $cf = 7;
        $cb = 0;
        $flash = 0; // flashing off
        $double = 0; // doubleheight off
        $graphics = 0; // text mode
        $seperated = 0; // normal graphics
        $holdgraph = 0; // hold mode off
        $holdchar = 32; // default hold char
        $conceal = 0; 
        // starting textpointer position
        $tp = 0;

        while ($tp < strlen($text)) {
            $char = ord($text{$tp}); // int!
            if ($doublebottom) { // if we're on the bottom row of a double height bit
                $char = $prev[$cx]; // use character from previous row!
            } else { // otherwise
                $prev[$cx] = $char; // store this character for next time ..
            } 

            $fnum = $fontnum;
            if ($format < 3) {
                // strip top bit in image files
                $char = $char &127;
            } 
            if (($char &32) && $graphics) $holdchar = $char;
            if ($char < 32) {
                switch ($char + 128) { // just for consistency
                    case 128;
                    if ($black != 1) {
                        break;
                } 
                case 129:
                case 130:
                case 131:
                case 132:
                case 133:
                case 134:
                case 135:
                    $cf = $char;
                    $graphics = 0;
                    $conceal = 0;
                    break;
                case 136:
                    $flash = 1;
                    break;
                case 137:
                    $flash = 0;
                    break;
                case 140:
                    $double = 0;
                    break;
                case 141:
                    if (!$doublebottom) $nextbottom = 1;
                    $double = 1;
                    break;
                case 144;
                if ($black != 1) {
                    break;
                } 
                case 145:
                case 146:
                case 147:
                case 148:
                case 149:
                case 150:
                case 151:
                    $cf = $char-16;
                    $graphics = 1;
                    $conceal = 0;
                    break;
                case 152: // conceal
                    $conceal = 1;
                    break;
                case 153:
                    $seperated = 0;
                    break;
                case 154:
                    $seperated = 1;
                    break;
                case 156:
                    $cb = 0;
                    break;
                case 157:
                    $cb = $cf;
                    break;
                case 158:
                    $holdgraph = 1;
                    break;
                case 159:
                    $holdgraph = 0;
                    break;

                default: ;
                } // switch
                $char = 32;
                if ($holdgraph == 1 && $graphics == 1) $char = $holdchar;
            } 
            // are we a flasher - i.e. is anything visible flashing?
            if ($flash == 1 && $char > 32) {
                $flasher = 1;
                if ($flashcycle == 1) $char = 32;
            } 
            // concealed text
            if ($conceal == 1) $char = 32; 
            // only double height chars show up on line below a d.h character
            if (!$double && $doublebottom) $char = 32; 
            // offset to get graphics characters within fontfile
            if ($graphics) {
                if ($char &32) {
                    $char += 96;
                    if ($char >= 160) $char -= 32;
                    if ($seperated) $char += 64;
                } 
            } 
            // switch to alternate font files for double height
            if ($double) {
                if ($doublebottom) {
                    $fnum = $fontnumbot;
                } else {
                    $fnum = $fontnumtop;
                } 
            } 
            // draw background colour
            if ($cb > 0) imagefilledrectangle($my_img, $lborder + ($cx * $fwidth), $tborder + ($cy * $fheight), $lborder + (($cx + 1) * $fwidth-1), $tborder + (($cy + 1) * $fheight-1) , $cb); 
            // draw character
            imagestring($my_img, $fnum , $lborder + ($cx * $fwidth) , $tborder + ($cy * $fheight) , chr($char) , $cf); 
            // next..
            $cx++;
            if ($cx >= $width) {
                $cx = 0;
                $cy++;
                if ($cy >= $height) {
                    $cy = 0;
                } 
                $cf = 7;
                $cb = 0;
                $flash = 0; // flashing off
                $double = 0; // doubleheight off
                $graphics = 0; // text mode
                $seperated = 0; // normal graphics
                $holdgraph = 0; // hold mode off
                $holdchar = 32; // default hold char
                $conceal = 0;
                $doublebottom = $nextbottom;
                $nextbottom = 0;
            } 
            $tp++;
        } // while texppointer		      
        // write cache file
        if ($flasher == 0) {
            if ($donotcache != 1) {
                imagepng($my_img, "./cache/" . $page);
            } 
        } else {
            $fname = "./cache/" . $page . "_" . $flashcycle . ".gif";
            $frames[] = $fname;
            $framed[] = $flashdelay[$flashcycle];
            imagegif($my_img, $fname);
        } 
    } while ($flasher > 0 && $flashcycle < 1); 
    // display image
    if (($flasher == 0)) {
        header("Content-type: image/png");
        imagepng($my_img);
    } else {
        $gif = new GIFEncoder ($frames,
            $framed,
            0,
            2,
            1, 2, 3,
            "url"
            );
        $image = $gif->GetAnimation ();
        if ($donotcache != 1) {
            $fname = "./cache/" . $page . ".gif";
            fwrite (fopen ($fname, "wb"), $image);
        } 
        header ('Content-type:image/gif');
        echo $image;
    } 
	    // clean closedown
    for ($i = 0;$i < 8;$i++) imagecolordeallocate($my_img, $colour[$i]);

    imagedestroy($my_img);
} 

?>